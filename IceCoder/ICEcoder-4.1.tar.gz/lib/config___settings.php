<?php
// ICEcoder system settings
$ICEcoderSettings = array(
	"versionNo"		=> "4.1",
	"codeMirrorDir"		=> "CodeMirror-4.2",
	"docRoot"		=> $_SERVER['DOCUMENT_ROOT'],
	"demoMode"		=> false,
	"devMode"		=> false,
	"loginRequired"		=> true,
	"multiUser"		=> false,
	"lineEnding"		=> "\n",
	"enableRegistration"	=> true
);
?>